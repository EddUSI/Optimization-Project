Newton <-
function(f, x0, nIter = 100, tol = 1e-9) { 
  for (t in 1:nIter) {
    if (abs(deriv(f, x0)) < tol) { #controls if the the first derivative of f is already enough near to zero
      break                        #if it is enough near to zero, it breaks
    }
    
    s <- -deriv(f, x0) / deriv(f, x0, ord = 2)  # calculates s as the quotient of the first and second derivative
    x0 <- x0 + s  # calculates the new x0 as the sum of the old one and s
  }
  
  return(x0)
}
