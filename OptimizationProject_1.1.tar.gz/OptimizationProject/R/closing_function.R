closing_function <-
function() {
  return("Goodbye!")
}
