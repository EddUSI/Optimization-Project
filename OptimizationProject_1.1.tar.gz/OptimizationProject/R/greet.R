greet <-
function(name) {
  greeting <- paste0("Hello, ", name, "! How are you?")
  return(greeting)
}
