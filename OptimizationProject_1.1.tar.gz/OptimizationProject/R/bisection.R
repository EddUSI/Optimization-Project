bisection <-
function(f, R, tol = 1e-5, nIter = 10000) {
  a <- R[1]  # defines a as the first element of R
  b <- R[2]  # defines b as the second element of R
  
  for (it in 1:nIter) {
    c <- a + (b - a) / 2  # calculate c
    
    df <- deriv(f, c)  # calculates the derivative of f at the point c with the deriv() function
    
    if (abs(df) < tol) {  # controls if df is already small enough (enough near to zero)
      break               # if it is enough near to zero, it stopps
    }
    
    if (df < 0) {  # checks if df is negative (max condition)
      b <- c  # c becomes the new b
    } else {
      a <- c  # c becomes the new a
    }
  }
  
  return((a + b) / 2)
}
