deriv <-
function(f, x0, ord = 1, h = 2^(-5)) {
  # numerical derivation with central differences
  if (ord <= 0) {
    return(f(x0))
  } else {
    fp <- deriv(f, x0 + h, ord = ord - 1, h = h)
    fm <- deriv(f, x0 - h, ord = ord - 1, h = h)
    return((fp - fm) / (2 * h))
  }
}
